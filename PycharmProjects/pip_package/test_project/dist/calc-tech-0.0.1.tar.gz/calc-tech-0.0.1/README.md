Contains library functions for Alps
